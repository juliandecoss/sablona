from json import dumps
from os import getenv

from dotenv import find_dotenv, load_dotenv

# Load .env file.
load_dotenv(find_dotenv())


def main(event: dict, context) -> dict:
    body = {
        "message": "Hello from Konfio!",
        "env": getenv("ENV"),
        "requestId": context.aws_request_id,
        "event": event,
    }

    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "isBase64Encoded": False,
        "body": dumps(body),
    }
