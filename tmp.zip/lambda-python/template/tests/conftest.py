from faker import Faker
from pytest import fixture


@fixture(autouse=True)
def disable_botocore(monkeypatch):
    monkeypatch.delattr("botocore.client.BaseClient._make_api_call")


@fixture(scope="session")
def faker():
    return Faker()
