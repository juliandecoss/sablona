from json import loads

from index import handler


def test_handler(monkeypatch, faker):
    env = faker.pystr()

    monkeypatch.setenv("ENV", env)

    class MockContext:
        aws_request_id = faker.uuid4()

    event = {"key": faker.pystr()}
    context = MockContext()

    response = handler(event=event, context=context)
    response_body = loads(response["body"])

    assert response["statusCode"] == 200
    assert response["headers"]
    assert response_body["env"] == env
    assert response_body["requestId"] == context.aws_request_id
    assert response_body["event"]["key"] == event["key"]
