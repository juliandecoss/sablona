from os import environ
from time import perf_counter
from traceback import print_exc
from uuid import uuid4

from index import handler

if not environ.get("ENV"):
    from dotenv import load_dotenv

    load_dotenv()


class Context:
    def __init__(self) -> None:
        self.aws_region = environ["AWS_REGION"]
        self.aws_account = environ["AWS_ACCOUNT_ID"]
        self.lambda_alias = environ["STAGE"]
        self.invoked_function_arn = f"arn:aws:lambda:{self.aws_region}:{self.aws_account}:function:${{ values.name }}:{self.lambda_alias}"
        self.aws_request_id = str(uuid4())


def get_event() -> dict:
    try:
        from event import EVENT as event
    except (ImportError, ModuleNotFoundError):
        from json import load
        from os import getcwd

        event_file_path = f"{getcwd()}/event.local.json"
        with open(event_file_path) as f:
            event = load(f)
    return event


def exec_time(start_time: float) -> str:
    total_time = perf_counter() - start_time
    unit = "s"
    if total_time > 60:
        total_time = total_time / 60
        unit = "min"
        if total_time > 60:
            total_time = total_time / 60
            unit = "h"
    return f"{total_time} {unit}"


def main() -> None:
    start_time = perf_counter()
    try:
        event = get_event()
        context = Context()
        result = handler(event, context)
        print(result)
    except:
        print_exc()
    finally:
        print(exec_time(start_time))


if __name__ == "__main__":
    main()
