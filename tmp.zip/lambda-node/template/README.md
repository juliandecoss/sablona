{%- set repoOwner -%}https://${{ values.repo.host }}/konfio/organization/tribes/${{ values.tribe }}/${{ values.repo.owner }}{%- endset -%}
{%- set repo -%}${{ repoOwner }}/${{ values.name }}{%- endset -%}
[![pipeline status](${{ repo }}/badges/main/pipeline.svg)](${{ repo }}/commits/main)
[![coverage report](${{ repo }}/badges/main/coverage.svg)](${{ repo }}/commits/main)


# ${{ values.name  }}

> This project was created with Konfio's Dev Portal

${{ values.description }}


## Getting started

Make sure you have installed

- [Node 18.x](https://nodejs.org/en/download/)
- [AWS CLI](https://docs.aws.amazon.com/cli/latest/userguide/install-macos.html)
- [Terraform](https://learn.hashicorp.com/terraform/getting-started/install.html)


## Installation

Make sure you have configured your `aws-cli`, you can check this by executing the next command:
```sh
aws configure
```

Setup your workspace:
```sh
git clone ${{ repo }}.git ${{ values.name }}
cd ${{ values.name }}
make setup
```


## Environment variables

To add new environment variables, ask a project mantainer to add them to the project's CI/CD Variables.
Be sure to tell them the name of the variable you are expecting based on the instructions below.

Also, you need to make the following code changes:

### Non-secret values

The name of the environment variable to be set in the project's CI/CD Variables will be `TF_VAR_{your_var_name}`.

For non-secret values, you need to add the necessary [Terraform configuration](#terraform-configuration).

### Sensitive values

These should be handled by AWS Secrets Manager on your tribe or squad 
[InfraOps](${{ repoOwner }}/infraops/-/blob/master/aws-main/secrets) repository.

### Terraform Configuration

Add the env vars declarations at the `infrastructure/globals/variables.tf` file:
```tf
variable "{your_var_name}" {
  type = string
}
```

Then, add the `variable`s as key-value pairs to the lambda's definition `environment` property at the
`infrastructure/main.tf` file:
```tf
environment = {
  <ENV_VAR_NAME> = var.{your_var_name}
}
```

You can also add ternary conditionals for different environments, *e.g.*:
```tf
DB = var.env == "prod" ? var.db_prod : var.db_dev
```


## Testing

To run your tests, execute:
```sh
make tests
```

### Local Debugging

By completing the [Installation](#installation) section, the `app.js`, `.env` & `event.local.json` files will be
created. Edit them as you need.

After you're done, run the code:
```sh
make run ENV=<your_qualifier> // default: 'dev'
```

#### VS Code

Setup your workspace to run the code on VS Code's debugger:
```sh
make set-debug-vscode
```

This will create the debugger configuration. If you already have one, add the snippet at `conf/vscode-launch.json`.

After you're done editing the files mentioned in [Local Debugging](#local-debugging), run the debugger using
"${{ values.name }}" configuration (you might need to open the Debug Console).

### Invoke lambda

You can invoke your remote lambda from your console.

You must have your AWS credentials configured, as mentioned in [Installation](#installation).

Create or edit the `event.local.json` file, adding what you need as your lambda event, and run:
```sh
make invoke-remote ENV=<your_qualifier> // default: 'dev'
```


## Validations

During a pipeline, we will be running these validations:
- terraform: Code Syntax and valid resource declarations
- eslint: code linting

To check your code against everything, run:
```sh
make lint
```

Some of the errors can be fixed automatically through:
```sh
make lint-fix
```

To check both lint and testing, run:
```sh
make validate
```


## Documentation

Add or edit any file at `docs/` and edit `mkdocs.yml` file, if needed, to watch your documentation at
[Konfio's Dev Portal](https://developer.konfio.mx/)


## Maintainers
- Email: ${{ values.email }}
