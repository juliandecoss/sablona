const dotenv = require('dotenv');
const dotenvExpand = require('dotenv-expand');

const myEnv = dotenv.config();
dotenvExpand.expand(myEnv);

module.exports = async (event, context, callback) => {
  const body = {
    message: 'Hello from Konfio!',
    env: process.env.ENV,
    requestId: context.awsRequestId,
    event,
    callback,
  };

  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
    },
    isBase64Encoded: false,
    body: JSON.stringify(body, null, 2),
  };
};
