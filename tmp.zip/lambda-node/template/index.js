const app = require('./src/app');

exports.handler = async (event, context, callback) => app(event, context, callback);
