const { randomUUID } = require('crypto');

const { faker } = require('@faker-js/faker');

const { handler } = require('../index');

describe('Sample test suite', () => {
  const env = faker.lorem.word();

  beforeAll(() => {
    process.env.ENV = env;
  });

  it('Sample test', async () => {
    class ContextMock {
      constructor() {
        this.awsRequestId = randomUUID();
      }
    }

    const event = { key: faker.lorem.word() };
    const context = new ContextMock();

    const response = await handler(event, context);
    const responseBody = JSON.parse(response.body);

    expect(response.statusCode).toBe(200);
    expect(response.headers).toBeDefined();
    expect(response.isBase64Encoded).toBe(false);
    expect(responseBody.env).toBe(env);
    expect(responseBody.requestId).toBe(context.awsRequestId);
    expect(responseBody.event.key).toBe(event.key);
  });
});
