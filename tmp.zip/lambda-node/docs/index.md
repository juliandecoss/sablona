# Overview

Template to create an AWS Lambda function with Node runtime.

This template uses Foundations tribe's [`terraform-aws-lambda` module](https://gitlab.com/konfio/organization/tribes/platform-foundations/infrastructure-as-code/catalog/provider/aws/terraform-aws-lambda)
from the module catalog.

Use this template to create a lambda function packaged as ZIP archive.

To start, you will need to fill the template's form steps that include some parameters needed for the repository and
lambda function. These include, among others:

- AWS account and region
- Repository/lambda name
- Tribe, squad, and component's owner

This will create a repository at the specified path on [*Choose a location*](#choose-a-location) form step, which will
trigger a pipeline that will create the lambda function in AWS, right out-of-the-box.

The Template will also register the component in the Dev Portal's [catalog](https://developer.konfio.mx/catalog).

After the repository has been created and the component has been registered, you can go to your fresh repository and
read the `README.md` to learn more about the repository and getting started with it, as well as starting to modifiy the
`src/app.js` file and add your awesome code.


## Choose a location

For this step, you need to add a couple of parameters:

- *Owner*: the target path where the repository will be created at inside `konfio/organization/tribes` [group](https://gitlab.com/konfio/organization/tribes)
  - The tribe's group name will be taken from a previous step
  - *e.g.* `template/backstage`
- *Repository*: the repo's name, this should be the same as the lambda's name
  - *e.g.* `my-awesome-lambda`


## Demo

Watch the [video](https://drive.google.com/file/d/1cyNbLzU6eV8ii9EuXQk4GmBcfXnO05gz/view?usp=sharing)
